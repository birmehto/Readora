import 'package:free/core/routes/app_routes.dart';
import 'package:get/get.dart';
import 'package:dio/dio.dart';
import 'package:html/parser.dart' as html_parser;
import 'package:html/dom.dart';
import 'package:share_plus/share_plus.dart';

import '../../../core/utils/error_handler.dart';
import '../../../core/utils/url_validator.dart';
import '../../../core/utils/share_helper.dart';
import '../../../core/network/network_info.dart';
import '../../../core/error/failures.dart';
import '../../../core/services/deep_link_service.dart';
import '../../history/controller/reading_history_controller.dart';
import '../model.dart';

class ArticleController extends GetxController {
  final Dio dio;
  final NetworkInfo networkInfo;

  ArticleController({required this.dio, required this.networkInfo});

  final _isLoading = false.obs;
  final _article = Rxn<Article>();
  final _error = RxnString();
  final _urlInput = ''.obs;

  @override
  void onInit() {
    super.onInit();
    // Check if there's a URL parameter in the route
    final urlParam = Get.parameters['url'];
    if (urlParam != null && urlParam.isNotEmpty) {
      // Decode the URL parameter
      final decodedUrl = Uri.decodeComponent(urlParam);
      fetchArticle(decodedUrl);
    }
  }

  bool get isLoading => _isLoading.value;
  Article? get article => _article.value;
  String? get error => _error.value;
  String get urlInput => _urlInput.value;

  void setUrlInput(String url) {
    _urlInput.value = url;
    if (_error.value != null) {
      _error.value = null;
    }
  }

  Future<void> fetchArticle(String url) async {
    final validationError = UrlValidator.validateUrl(url);
    if (validationError != null) {
      _error.value = validationError;
      return;
    }

    _isLoading.value = true;
    _error.value = null;

    try {
      if (await networkInfo.isConnected) {
        final article = await _getArticle(url);
        _article.value = article;
        ErrorHandler.logInfo('ArticleController', 'Loaded: ${article.title}');

        // Navigate directly to article view after successful fetch
        Get.toNamed(AppRoutes.article);
      } else {
        _error.value = 'No internet connection';
      }
    } catch (e) {
      if (e is Failure) {
        _error.value = e.message;
      } else {
        _error.value = e.toString();
      }
      ErrorHandler.logError('ArticleController', 'Error: ${_error.value}');
    }

    _isLoading.value = false;
  }

  Future<Article> _getArticle(String url) async {
    try {
      final freediumUrl = _createFreediumUrl(url);
      final response = await dio.get(freediumUrl);

      if (response.statusCode == 200) {
        return _parseArticle(response.data.toString(), url);
      } else {
        throw ServerFailure('Failed to load article: ${response.statusCode}');
      }
    } catch (e) {
      if (e is Failure) rethrow;
      throw ServerFailure(e.toString());
    }
  }

  String _createFreediumUrl(String url) {
    if (url.contains('freedium.cfd')) return url;
    return 'https://freedium.cfd/${url.replaceFirst(RegExp(r'^https?://'), '')}';
  }

  Article _parseArticle(String htmlContent, String originalUrl) {
    final document = html_parser.parse(htmlContent);

    final title = _extractTitle(document);
    final author = _extractAuthor(document);
    final subtitle = _extractSubtitle(document);
    final content = _extractContent(document);
    final publishedDate = _extractPublishDate(document);
    final imageUrl = _extractImageUrl(document);
    final authorImageUrl = _extractAuthorImageUrl(document);
    final readingTime = _extractReadingTime(document);
    final tags = _extractTags(document);

    if (title.isEmpty && content.isEmpty) {
      throw const ParsingFailure(
        'Could not extract article content. The article might be behind a paywall or the URL is invalid.',
      );
    }

    return Article(
      title: title,
      author: author,
      subtitle: subtitle,
      content: content,
      publishedDate: publishedDate,
      originalUrl: originalUrl,
      imageUrl: imageUrl,
      authorImageUrl: authorImageUrl,
      readingTime: readingTime,
      tags: tags,
    );
  }

  String _extractTitle(Document document) {
    final titleSelectors = [
      'h1[data-testid="storyTitle"]',
      'h1.graf--title',
      'h1.p-name',
      'h1',
      '[data-testid="storyTitle"]',
      '.graf--title',
      'article h1',
      'main h1',
    ];

    for (final selector in titleSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null && element.text.trim().isNotEmpty) {
          String title = element.text.trim();
          if (title.contains(' - ')) {
            title = title.split(' - ')[0];
          }
          if (title.length > 10) {
            return title;
          }
        }
      } catch (e) {
        continue;
      }
    }

    try {
      final titleElement = document.querySelector('title');
      if (titleElement != null) {
        String title = titleElement.text.trim();
        if (title.contains(' | ')) {
          title = title.split(' | ')[0];
        }
        if (title.contains(' - ')) {
          title = title.split(' - ')[0];
        }
        return title.isNotEmpty ? title : 'Untitled Article';
      }
    } catch (e) {
      // Ignore
    }

    return 'Untitled Article';
  }

  String _extractAuthor(Document document) {
    final authorSelectors = [
      '[data-testid="authorName"]',
      'a[data-testid="authorName"]',
      '.author-name',
      '[rel="author"]',
      '.u-accentColor--textNormal',
      '.p-author',
      '.followState button',
      'article [data-testid="authorName"]',
      '.author',
      '.byline-name',
      '.post-author',
      'span[data-testid="authorName"]',
      '.js-authorName',
      '.author-link',
      'meta[name="author"]',
      'meta[property="article:author"]',
    ];

    for (final selector in authorSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null) {
          String authorText = '';

          // Try to get content from different attributes
          if (element.attributes['content'] != null) {
            authorText = element.attributes['content']!;
          } else if (element.text.trim().isNotEmpty) {
            authorText = element.text.trim();
          }

          if (authorText.isNotEmpty && authorText.length > 1) {
            // Clean up author name
            authorText = authorText.replaceAll(RegExp(r'\s+'), ' ');
            if (authorText.toLowerCase() != 'follow' &&
                authorText.toLowerCase() != 'subscribe' &&
                !authorText.contains('@') &&
                authorText.length < 100) {
              return authorText;
            }
          }
        }
      } catch (e) {
        continue;
      }
    }

    // Try to extract from JSON-LD structured data
    try {
      final scripts = document.querySelectorAll(
        'script[type="application/ld+json"]',
      );
      for (final script in scripts) {
        final jsonText = script.text;
        if (jsonText.contains('"author"')) {
          // Simple regex to extract author name from JSON-LD
          final authorMatch = RegExp(
            r'"author"[^}]*"name"\s*:\s*"([^"]+)"',
          ).firstMatch(jsonText);
          if (authorMatch != null) {
            return authorMatch.group(1)!.trim();
          }
        }
      }
    } catch (e) {
      // Ignore JSON parsing errors
    }

    return 'Unknown Author';
  }

  String? _extractSubtitle(Document document) {
    final subtitleSelectors = [
      'h2[data-testid="storySubtitle"]',
      'h2.graf--subtitle',
      '.subtitle',
      'h2.p-summary',
      'article h2',
    ];

    for (final selector in subtitleSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null && element.text.trim().isNotEmpty) {
          return element.text.trim();
        }
      } catch (e) {
        continue;
      }
    }

    return null;
  }

  String _extractContent(Document document) {
    final contentSelectors = [
      'article section',
      '[data-testid="storyContent"]',
      'article',
      '.postArticle-content',
      '.section-content',
      'main article',
      'main section',
      '.e-content',
      '.post-content',
      '.entry-content',
    ];

    for (final selector in contentSelectors) {
      try {
        final contentElement = document.querySelector(selector);
        if (contentElement != null) {
          // Remove unwanted elements
          _removeUnwantedElements(contentElement);

          // Get HTML content instead of just text
          final htmlContent = contentElement.innerHtml;

          if (htmlContent.isNotEmpty && htmlContent.length > 100) {
            return _cleanHtmlContent(htmlContent);
          }
        }
      } catch (e) {
        continue;
      }
    }

    // Fallback: try to get content from paragraphs
    try {
      final paragraphs = document.querySelectorAll(
        'p, h1, h2, h3, h4, h5, h6, blockquote, pre, ul, ol',
      );
      final contentBuffer = StringBuffer();

      for (final paragraph in paragraphs) {
        final text = paragraph.text.trim();
        if (text.isNotEmpty &&
            text.length > 15 &&
            !_isNavigationText(text) &&
            !_isAdText(text)) {
          // Preserve HTML structure for better rendering
          final tagName = paragraph.localName;
          final innerHTML = paragraph.innerHtml;

          contentBuffer.writeln('<$tagName>$innerHTML</$tagName>');
        }
      }

      final content = contentBuffer.toString().trim();
      return content.isNotEmpty ? content : 'Content could not be extracted.';
    } catch (e) {
      return 'Content could not be extracted.';
    }
  }

  void _removeUnwantedElements(Element contentElement) {
    // Remove navigation, ads, and other unwanted elements
    final unwantedSelectors = [
      '.follow-button',
      '.subscribe-button',
      '.social-share',
      '.related-articles',
      '.advertisement',
      '.ad-container',
      '.newsletter-signup',
      '.author-follow',
      '.clap-button',
      '.highlight-menu',
      '.response-count',
      '.bookmark-button',
      '[data-testid="storyReadTime"]',
      '.member-preview-upgrade',
      '.paywall',
    ];

    for (final selector in unwantedSelectors) {
      try {
        final elements = contentElement.querySelectorAll(selector);
        for (final element in elements) {
          element.remove();
        }
      } catch (e) {
        continue;
      }
    }
  }

  String _cleanHtmlContent(String htmlContent) {
    // Clean up the HTML content
    String cleaned = htmlContent;

    // Remove empty paragraphs and divs
    cleaned = cleaned.replaceAll(RegExp(r'<p[^>]*>\s*</p>'), '');
    cleaned = cleaned.replaceAll(RegExp(r'<div[^>]*>\s*</div>'), '');

    // Remove style attributes for consistent styling
    cleaned = cleaned.replaceAll(RegExp(r'\s*style="[^"]*"'), '');

    // Remove class attributes that might interfere with styling
    cleaned = cleaned.replaceAll(RegExp(r'\s*class="[^"]*"'), '');

    // Remove data attributes
    cleaned = cleaned.replaceAll(RegExp(r'\s*data-[^=]*="[^"]*"'), '');

    // Clean up extra whitespace
    cleaned = cleaned.replaceAll(RegExp(r'\s+'), ' ');
    cleaned = cleaned.replaceAll(RegExp(r'>\s+<'), '><');

    return cleaned.trim();
  }

  bool _isNavigationText(String text) {
    final navPatterns = [
      'sign up',
      'sign in',
      'follow',
      'subscribe',
      'member-only',
      'upgrade',
      'get unlimited',
      'read more',
      'continue reading',
      'view all',
      'see all',
      'more from',
      'recommended',
      'related',
    ];

    final lowerText = text.toLowerCase();
    return navPatterns.any((pattern) => lowerText.contains(pattern));
  }

  bool _isAdText(String text) {
    final adPatterns = [
      'advertisement',
      'sponsored',
      'promoted',
      'affiliate',
      'disclosure',
      'privacy policy',
      'terms of service',
      'cookie',
    ];

    final lowerText = text.toLowerCase();
    return adPatterns.any((pattern) => lowerText.contains(pattern));
  }

  DateTime? _extractPublishDate(Document document) {
    final dateSelectors = [
      '[data-testid="storyPublishDate"]',
      'time',
      '.published-date',
      '[datetime]',
      '.dt-published',
    ];

    for (final selector in dateSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null) {
          final dateText =
              element.attributes['datetime'] ??
              element.attributes['title'] ??
              element.text;
          if (dateText.isNotEmpty) {
            final date = DateTime.tryParse(dateText);
            if (date != null) {
              return date;
            }
          }
        }
      } catch (e) {
        continue;
      }
    }

    return null;
  }

  String? _extractImageUrl(Document document) {
    final imageSelectors = [
      'article img',
      '[data-testid="storyImage"] img',
      '.graf--figure img',
      'figure img',
      'img[data-testid="image"]',
      'meta[property="og:image"]',
    ];

    for (final selector in imageSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null) {
          String? imageUrl =
              element.attributes['src'] ??
              element.attributes['data-src'] ??
              element.attributes['content'];
          if (imageUrl != null && imageUrl.isNotEmpty) {
            if (imageUrl.startsWith('http') || imageUrl.startsWith('//')) {
              if (imageUrl.startsWith('//')) {
                imageUrl = 'https:$imageUrl';
              }
              return imageUrl;
            }
          }
        }
      } catch (e) {
        continue;
      }
    }
    return null;
  }

  String? _extractAuthorImageUrl(Document document) {
    final authorImageSelectors = [
      '[data-testid="authorPhoto"] img',
      'img[data-testid="authorPhoto"]',
      '.avatar img',
      '.author-image img',
      '.author-avatar img',
      '.u-photo img',
      '.profile-image img',
      '.author-photo img',
      '.byline-avatar img',
      'img.avatar',
      'img[alt*="author"]',
      'img[alt*="Author"]',
    ];

    for (final selector in authorImageSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null) {
          String? imageUrl =
              element.attributes['src'] ??
              element.attributes['data-src'] ??
              element.attributes['data-lazy-src'] ??
              element.attributes['srcset']?.split(' ').first;

          if (imageUrl != null && imageUrl.isNotEmpty) {
            // Clean up the URL
            if (imageUrl.startsWith('//')) {
              imageUrl = 'https:$imageUrl';
            } else if (!imageUrl.startsWith('http')) {
              continue; // Skip relative URLs
            }

            // Validate that it's likely an image URL
            if (imageUrl.contains('avatar') ||
                imageUrl.contains('profile') ||
                imageUrl.contains('author') ||
                imageUrl.endsWith('.jpg') ||
                imageUrl.endsWith('.jpeg') ||
                imageUrl.endsWith('.png') ||
                imageUrl.endsWith('.webp')) {
              return imageUrl;
            }
          }
        }
      } catch (e) {
        continue;
      }
    }

    // Try to find author image from structured data
    try {
      final scripts = document.querySelectorAll(
        'script[type="application/ld+json"]',
      );
      for (final script in scripts) {
        final jsonText = script.text;
        if (jsonText.contains('"author"') && jsonText.contains('"image"')) {
          final imageMatch = RegExp(
            r'"author"[^}]*"image"\s*:\s*"([^"]+)"',
          ).firstMatch(jsonText);
          if (imageMatch != null) {
            return imageMatch.group(1)!;
          }
        }
      }
    } catch (e) {
      // Ignore JSON parsing errors
    }

    return null;
  }

  int? _extractReadingTime(Document document) {
    final readingTimeSelectors = [
      '[data-testid="storyReadTime"]',
      '.readingTime',
      '.reading-time',
      '.post-reading-time',
    ];

    for (final selector in readingTimeSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null) {
          final text = element.text.toLowerCase();
          final match = RegExp(r'(\d+)').firstMatch(text);
          if (match != null) {
            return int.tryParse(match.group(1)!);
          }
        }
      } catch (e) {
        continue;
      }
    }

    final wordCount = _estimateWordCount(document);
    if (wordCount > 0) {
      return (wordCount / 200).ceil();
    }
    return null;
  }

  int _estimateWordCount(Document document) {
    try {
      final contentElement = document.querySelector('article') ?? document;
      final text = contentElement.text;
      if (text == null || text.isEmpty) return 0;
      return text.split(RegExp(r'\s+')).where((word) => word.isNotEmpty).length;
    } catch (e) {
      return 0;
    }
  }

  List<String> _extractTags(Document document) {
    final tagSelectors = [
      '.tags a',
      '.post-tags a',
      '[data-testid="tag"]',
      '.tag',
    ];

    final tags = <String>[];

    for (final selector in tagSelectors) {
      try {
        final elements = document.querySelectorAll(selector);
        for (final element in elements) {
          final tagText = element.text.trim();
          if (tagText.isNotEmpty && !tags.contains(tagText)) {
            tags.add(tagText);
          }
        }
      } catch (e) {
        continue;
      }
    }

    return tags.take(5).toList();
  }

  void retryLastFetch() {
    if (_urlInput.value.isNotEmpty) {
      fetchArticle(_urlInput.value);
    }
  }

  void reset() {
    _article.value = null;
    _error.value = null;
    _urlInput.value = '';
  }

  void bookmarkArticle() {
    if (_article.value != null) {
      try {
        final historyController = Get.find<ReadingHistoryController>();
        historyController.toggleFavorite(_article.value!);
      } catch (_) {}
    }
  }

  bool isBookmarked() {
    if (_article.value != null) {
      try {
        final historyController = Get.find<ReadingHistoryController>();
        return historyController.isFavorite(_article.value!);
      } catch (_) {
        return false;
      }
    }
    return false;
  }

  void setArticle(Article article) {
    _article.value = article;
    _error.value = null;
    try {
      final historyController = Get.find<ReadingHistoryController>();
      historyController.addToHistory(article);
    } catch (_) {}
  }

  // Helper method to navigate to article with URL
  static void openArticleFromUrl(String url) {
    final encodedUrl = Uri.encodeComponent(url);
    Get.toNamed('${AppRoutes.article}/$encodedUrl');
  }

  // Helper method to share article with native sharing
  Future<void> shareArticleNative() async {
    if (_article.value != null) {
      await ShareHelper.shareArticle(_article.value!);
    }
  }
}
