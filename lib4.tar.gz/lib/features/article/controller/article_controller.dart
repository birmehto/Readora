import 'package:flutter/material.dart';
import 'package:free/core/routes/app_routes.dart';
import 'package:get/get.dart';
import 'package:dio/dio.dart';
import 'package:html/parser.dart' as html_parser;
import 'package:html/dom.dart' as html;

import '../../../core/utils/error_handler.dart';
import '../../../core/utils/url_validator.dart';
import '../../../core/utils/share_helper.dart';
import '../../../core/network/network_info.dart';
import '../../../core/error/failures.dart';
import '../../history/controller/reading_history_controller.dart';
import '../model.dart';

class ArticleController extends GetxController {
  final Dio dio;
  final NetworkInfo networkInfo;

  ArticleController({required this.dio, required this.networkInfo});

  final _isLoading = false.obs;
  final _article = Rxn<Article>();
  final _error = RxnString();
  final _urlInput = ''.obs;

  @override
  void onInit() {
    super.onInit();
    // Check if there's a URL parameter in the route
    final urlParam = Get.parameters['url'];
    if (urlParam != null && urlParam.isNotEmpty) {
      // Decode the URL parameter
      final decodedUrl = Uri.decodeComponent(urlParam);
      fetchArticle(decodedUrl);
    }
  }

  bool get isLoading => _isLoading.value;
  Article? get article => _article.value;
  String? get error => _error.value;
  String get urlInput => _urlInput.value;

  void setUrlInput(String url) {
    _urlInput.value = url;
    if (_error.value != null) {
      _error.value = null;
    }
  }

  Future<void> fetchArticle(String url) async {
    final validationError = UrlValidator.validateUrl(url);
    if (validationError != null) {
      _error.value = validationError;
      return;
    }

    _isLoading.value = true;
    _error.value = null;

    try {
      if (await networkInfo.isConnected) {
        final article = await _getArticle(url);
        _article.value = article;
        ErrorHandler.logInfo(
          'ArticleController',
          'Successfully loaded: ${article.title}',
        );

        // Navigate directly to article view after successful fetch
        Get.toNamed(AppRoutes.article);
      } else {
        _error.value =
            'No internet connection. Please check your network and try again.';
      }
    } catch (e) {
      String errorMessage;

      if (e is Failure) {
        errorMessage = e.message;
      } else {
        final errorStr = e.toString().toLowerCase();

        if (errorStr.contains('freedium') && errorStr.contains('host lookup')) {
          errorMessage =
              'Freedium service is currently unavailable. Cannot access premium content. Please check your internet connection or try again later.';
        } else if (errorStr.contains('freedium')) {
          errorMessage =
              'Freedium premium access failed. The article may still be behind a paywall or the service is temporarily down.';
        } else if (errorStr.contains('paywall')) {
          errorMessage =
              'This article is behind a paywall. Premium content access failed.';
        } else if (errorStr.contains('timeout') ||
            errorStr.contains('connection')) {
          errorMessage =
              'Connection timeout. Please check your internet connection and try again.';
        } else if (errorStr.contains('404') || errorStr.contains('not found')) {
          errorMessage =
              'Article not found. Please check the URL and try again.';
        } else {
          errorMessage =
              'Failed to access premium content. Please try again or check if the URL is correct.';
        }
      }

      _error.value = errorMessage;
      ErrorHandler.logError('ArticleController', 'Error: $errorMessage');
    }

    _isLoading.value = false;
  }

  Future<Article> _getArticle(String url) async {
    // Prioritize Freedium for premium content access
    ErrorHandler.logInfo(
      'ArticleController',
      'Attempting to fetch premium content: $url',
    );

    // First, always try Freedium with multiple strategies for premium content
    try {
      return await _tryFreediumWithRetry(url);
    } catch (e) {
      ErrorHandler.logInfo('ArticleController', 'Freedium access failed: $e');
    }

    // If Freedium fails, try other methods as fallback (but warn about limited access)
    final fallbackAttempts = [
      () => _tryDirectUrl(url),
      () => _tryAlternativeServices(url),
    ];

    String? lastError;
    for (final attempt in fallbackAttempts) {
      try {
        final article = await attempt();
        // Warn user that premium content might not be available
        Get.snackbar(
          'Limited Access',
          'Article loaded via fallback. Premium content may be unavailable.',
          snackPosition: SnackPosition.TOP,
          backgroundColor: Colors.orange.withOpacity(0.8),
          colorText: Colors.white,
          duration: const Duration(seconds: 4),
        );
        return article;
      } catch (e) {
        lastError = e.toString();
        ErrorHandler.logInfo(
          'ArticleController',
          'Fallback attempt failed: $lastError',
        );
        continue;
      }
    }

    // If all attempts failed, throw the last error
    throw ServerFailure(
      lastError ?? 'Failed to fetch article from all sources',
    );
  }

  Future<Article> _tryFreediumWithRetry(String url) async {
    // Multiple Freedium strategies for better premium content access
    final freediumStrategies = [
      () => _tryFreediumUrl(url),
      () => _tryFreediumWithDelay(url),
      () => _tryFreediumAlternativeFormat(url),
    ];

    String? lastError;

    for (int i = 0; i < freediumStrategies.length; i++) {
      try {
        ErrorHandler.logInfo(
          'ArticleController',
          'Trying Freedium strategy ${i + 1}',
        );
        return await freediumStrategies[i]();
      } catch (e) {
        lastError = e.toString();
        ErrorHandler.logInfo(
          'ArticleController',
          'Freedium strategy ${i + 1} failed: $lastError',
        );

        // Wait a bit before trying next strategy
        if (i < freediumStrategies.length - 1) {
          await Future.delayed(Duration(milliseconds: 500 * (i + 1)));
        }
      }
    }

    throw ServerFailure('All Freedium strategies failed: $lastError');
  }

  Future<Article> _tryFreediumUrl(String url) async {
    try {
      final freediumUrl = _createFreediumUrl(url);
      ErrorHandler.logInfo(
        'ArticleController',
        'Accessing Freedium: $freediumUrl',
      );

      final response = await dio.get(
        freediumUrl,
        options: Options(
          receiveTimeout: const Duration(seconds: 45),
          headers: {
            'User-Agent':
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept':
                'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
          },
        ),
      );

      if (response.statusCode == 200) {
        final article = _parseArticle(response.data.toString(), url);
        ErrorHandler.logInfo(
          'ArticleController',
          'Successfully accessed premium content via Freedium',
        );

        // Show success message for premium access
        Get.snackbar(
          'Premium Access',
          'Article loaded with full premium content via Freedium',
          snackPosition: SnackPosition.TOP,
          backgroundColor: Colors.green.withOpacity(0.8),
          colorText: Colors.white,
          duration: const Duration(seconds: 3),
        );

        return article;
      } else {
        throw ServerFailure('Freedium returned status: ${response.statusCode}');
      }
    } catch (e) {
      throw ServerFailure('Freedium service error: ${e.toString()}');
    }
  }

  Future<Article> _tryFreediumWithDelay(String url) async {
    // Sometimes Freedium needs a moment to process
    await Future.delayed(const Duration(seconds: 2));
    return await _tryFreediumUrl(url);
  }

  Future<Article> _tryFreediumAlternativeFormat(String url) async {
    try {
      // Try different URL format for Freedium
      String alternativeUrl = url;
      if (url.contains('medium.com/')) {
        // Convert medium.com URLs to a format Freedium might handle better
        alternativeUrl = url.replaceAll('medium.com/', 'medium.com/');
      }

      final freediumUrl = 'https://freedium.cfd/$alternativeUrl';
      ErrorHandler.logInfo(
        'ArticleController',
        'Trying alternative Freedium format: $freediumUrl',
      );

      final response = await dio.get(
        freediumUrl,
        options: Options(
          receiveTimeout: const Duration(seconds: 45),
          headers: {
            'User-Agent':
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer': 'https://freedium.cfd/',
          },
        ),
      );

      if (response.statusCode == 200) {
        return _parseArticle(response.data.toString(), url);
      } else {
        throw ServerFailure(
          'Alternative Freedium format failed: ${response.statusCode}',
        );
      }
    } catch (e) {
      throw ServerFailure('Alternative Freedium format error: ${e.toString()}');
    }
  }

  Future<Article> _tryDirectUrl(String url) async {
    try {
      // Try to fetch the original URL directly
      final response = await dio.get(
        url,
        options: Options(
          receiveTimeout: const Duration(seconds: 30),
          headers: {
            'User-Agent':
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          },
        ),
      );

      if (response.statusCode == 200) {
        final article = _parseArticle(response.data.toString(), url);

        // Check if we got meaningful content
        if (article.content.length > 200 &&
            !article.content.contains('paywall')) {
          return article;
        } else {
          throw ServerFailure(
            'Article appears to be behind paywall or has insufficient content',
          );
        }
      } else {
        throw ServerFailure(
          'Direct access returned status: ${response.statusCode}',
        );
      }
    } catch (e) {
      throw ServerFailure('Direct access failed: ${e.toString()}');
    }
  }

  Future<Article> _tryAlternativeServices(String url) async {
    // List of alternative services that might work
    final alternatives = ['https://12ft.io/', 'https://archive.today/newest/'];

    for (final service in alternatives) {
      try {
        String serviceUrl;
        if (service.contains('12ft.io')) {
          serviceUrl = '$service${url}';
        } else if (service.contains('archive.today')) {
          serviceUrl = '${service}${url}';
        } else {
          continue;
        }

        final response = await dio.get(
          serviceUrl,
          options: Options(receiveTimeout: const Duration(seconds: 45)),
        );

        if (response.statusCode == 200) {
          final article = _parseArticle(response.data.toString(), url);

          // Check if we got meaningful content
          if (article.content.length > 200) {
            return article;
          }
        }
      } catch (e) {
        // Continue to next service
        continue;
      }
    }

    throw ServerFailure('All alternative services failed');
  }

  String _createFreediumUrl(String url) {
    if (url.contains('freedium.cfd')) return url;

    // Clean the URL for better Freedium compatibility
    String cleanUrl = url.trim();

    // Remove protocol
    cleanUrl = cleanUrl.replaceFirst(RegExp(r'^https?://'), '');

    // Remove trailing slashes and fragments
    cleanUrl = cleanUrl.replaceAll(RegExp(r'[/#?].*$'), '');

    // Handle specific Medium URL formats for better Freedium access
    if (cleanUrl.contains('medium.com')) {
      // Ensure proper Medium URL format for Freedium
      if (!cleanUrl.contains('medium.com/')) {
        cleanUrl = cleanUrl.replaceFirst('medium.com', 'medium.com/');
      }
    }

    final freediumUrl = 'https://freedium.cfd/$cleanUrl';
    ErrorHandler.logInfo(
      'ArticleController',
      'Created Freedium URL: $freediumUrl',
    );

    return freediumUrl;
  }

  Article _parseArticle(String htmlContent, String originalUrl) {
    final document = html_parser.parse(htmlContent);

    final title = _extractTitle(document);
    final author = _extractAuthor(document);
    final subtitle = _extractSubtitle(document);
    final content = _extractContent(document);
    final publishedDate = _extractPublishDate(document);
    final imageUrl = _extractImageUrl(document);
    final authorImageUrl = _extractAuthorImageUrl(document);
    final readingTime = _extractReadingTime(document);
    final tags = _extractTags(document);

    if (title.isEmpty && content.isEmpty) {
      throw const ParsingFailure(
        'Could not extract article content. The article might be behind a paywall or the URL is invalid.',
      );
    }

    return Article(
      title: title,
      author: author,
      subtitle: subtitle,
      content: content,
      publishedDate: publishedDate,
      originalUrl: originalUrl,
      imageUrl: imageUrl,
      authorImageUrl: authorImageUrl,
      readingTime: readingTime,
      tags: tags,
    );
  }

  String _extractTitle(html.Document document) {
    // First try structured data from JSON-LD
    try {
      final scripts = document.querySelectorAll(
        'script[type="application/ld+json"]',
      );
      for (final script in scripts) {
        final jsonText = script.text;
        if (jsonText.contains('"headline"')) {
          final headlineMatch = RegExp(
            r'"headline"\s*:\s*"([^"]+)"',
          ).firstMatch(jsonText);
          if (headlineMatch != null) {
            return headlineMatch.group(1)!.trim();
          }
        }
        if (jsonText.contains('"name"')) {
          final nameMatch = RegExp(
            r'"name"\s*:\s*"([^"]+)"',
          ).firstMatch(jsonText);
          if (nameMatch != null) {
            final title = nameMatch.group(1)!.trim();
            if (title.length > 10 && !title.toLowerCase().contains('medium')) {
              return title;
            }
          }
        }
      }
    } catch (e) {
      // Continue with other methods
    }

    // Try meta tags
    final metaSelectors = [
      'meta[property="og:title"]',
      'meta[property="twitter:title"]',
      'meta[name="title"]',
    ];

    for (final selector in metaSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null) {
          final content = element.attributes['content'];
          if (content != null &&
              content.trim().isNotEmpty &&
              content.length > 10) {
            String title = content.trim();
            // Clean up common suffixes
            title = title.replaceAll(
              RegExp(r'\s*\|\s*by\s+.*$', caseSensitive: false),
              '',
            );
            title = title.replaceAll(
              RegExp(r'\s*\|\s*Medium$', caseSensitive: false),
              '',
            );
            title = title.replaceAll(RegExp(r'\s*\|\s*.*$'), '');
            return title;
          }
        }
      } catch (e) {
        continue;
      }
    }

    // Try HTML selectors
    final titleSelectors = [
      'h1[data-testid="storyTitle"]',
      'h1.pw-post-title',
      'h1.graf--title',
      'h1.p-name',
      'article h1',
      'main h1',
      'h1',
    ];

    for (final selector in titleSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null && element.text.trim().isNotEmpty) {
          String title = element.text.trim();
          if (title.length > 10) {
            return title;
          }
        }
      } catch (e) {
        continue;
      }
    }

    // Fallback to page title
    try {
      final titleElement = document.querySelector('title');
      if (titleElement != null) {
        String title = titleElement.text.trim();
        title = title.replaceAll(
          RegExp(r'\s*\|\s*by\s+.*$', caseSensitive: false),
          '',
        );
        title = title.replaceAll(
          RegExp(r'\s*\|\s*Medium$', caseSensitive: false),
          '',
        );
        title = title.replaceAll(RegExp(r'\s*\|\s*.*$'), '');
        return title.isNotEmpty ? title : 'Untitled Article';
      }
    } catch (e) {
      // Ignore
    }

    return 'Untitled Article';
  }

  String _extractAuthor(html.Document document) {
    // First try structured data from JSON-LD
    try {
      final scripts = document.querySelectorAll(
        'script[type="application/ld+json"]',
      );
      for (final script in scripts) {
        final jsonText = script.text;
        if (jsonText.contains('"author"')) {
          // Try different JSON-LD patterns
          final patterns = [
            r'"author"[^}]*"name"\s*:\s*"([^"]+)"',
            r'"creator"[^}]*"name"\s*:\s*"([^"]+)"',
          ];

          for (final pattern in patterns) {
            final match = RegExp(pattern).firstMatch(jsonText);
            if (match != null) {
              final author = match.group(1)!.trim();
              if (author.isNotEmpty &&
                  author.length > 1 &&
                  author.length < 100) {
                return author;
              }
            }
          }
        }
      }
    } catch (e) {
      // Continue with other methods
    }

    // Try meta tags
    final metaSelectors = [
      'meta[name="author"]',
      'meta[property="article:author"]',
      'meta[property="author"]',
    ];

    for (final selector in metaSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null) {
          final content = element.attributes['content'];
          if (content != null && content.trim().isNotEmpty) {
            final author = content.trim();
            if (author.length > 1 &&
                author.length < 100 &&
                !author.toLowerCase().contains('http') &&
                !author.contains('@')) {
              return author;
            }
          }
        }
      } catch (e) {
        continue;
      }
    }

    // Try HTML selectors
    final authorSelectors = [
      '[data-testid="authorName"]',
      'a[data-testid="authorName"]',
      '.author-name',
      '[rel="author"]',
      '.u-accentColor--textNormal',
      '.p-author',
      'article [data-testid="authorName"]',
      '.author',
      '.byline-name',
      '.post-author',
      'span[data-testid="authorName"]',
      '.js-authorName',
      '.author-link',
    ];

    for (final selector in authorSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null) {
          String authorText = element.text.trim();

          if (authorText.isNotEmpty && authorText.length > 1) {
            // Clean up author name
            authorText = authorText.replaceAll(RegExp(r'\s+'), ' ');

            // Filter out common non-author text
            final excludePatterns = [
              'follow',
              'subscribe',
              'member',
              'upgrade',
              'sign up',
              'sign in',
              'get unlimited',
              'become a member',
              'join medium',
            ];

            final lowerText = authorText.toLowerCase();
            final isExcluded = excludePatterns.any(
              (pattern) => lowerText.contains(pattern),
            );

            if (!isExcluded &&
                !authorText.contains('@') &&
                !authorText.contains('http') &&
                authorText.length < 100) {
              return authorText;
            }
          }
        }
      } catch (e) {
        continue;
      }
    }

    return 'Unknown Author';
  }

  String? _extractSubtitle(html.Document document) {
    // Try meta description first
    try {
      final metaSelectors = [
        'meta[property="og:description"]',
        'meta[property="twitter:description"]',
        'meta[name="description"]',
      ];

      for (final selector in metaSelectors) {
        final element = document.querySelector(selector);
        if (element != null) {
          final content = element.attributes['content'];
          if (content != null &&
              content.trim().isNotEmpty &&
              content.length > 20) {
            String subtitle = content.trim();
            // Clean up if it's too long or seems like a generic description
            if (subtitle.length > 300) {
              subtitle = '${subtitle.substring(0, 300)}...';
            }
            // Skip if it looks like a generic site description
            if (!subtitle.toLowerCase().contains('medium') &&
                !subtitle.toLowerCase().contains('publication')) {
              return subtitle;
            }
          }
        }
      }
    } catch (e) {
      // Continue with other methods
    }

    // Try HTML selectors
    final subtitleSelectors = [
      'h2[data-testid="storySubtitle"]',
      'h2.graf--subtitle',
      '.subtitle',
      'h2.p-summary',
      'article h2:first-of-type',
      '.post-subtitle',
    ];

    for (final selector in subtitleSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null && element.text.trim().isNotEmpty) {
          final subtitle = element.text.trim();
          if (subtitle.length > 10 && subtitle.length < 500) {
            return subtitle;
          }
        }
      } catch (e) {
        continue;
      }
    }

    return null;
  }

  String _extractContent(html.Document document) {
    // First try to find the main article content area
    final contentSelectors = [
      'article section',
      '[data-testid="storyContent"]',
      'article',
      '.postArticle-content',
      '.section-content',
      'main article',
      'main section',
      '.e-content',
      '.post-content',
      '.entry-content',
    ];

    for (final selector in contentSelectors) {
      try {
        final contentElement = document.querySelector(selector);
        if (contentElement != null) {
          // Clone the element to avoid modifying the original
          final clonedElement = contentElement.clone(true);

          // Remove unwanted elements
          _removeUnwantedElements(clonedElement);

          // Get HTML content
          final htmlContent = clonedElement.innerHtml;

          if (htmlContent.isNotEmpty && htmlContent.length > 100) {
            final cleanedContent = _cleanHtmlContent(htmlContent);
            if (cleanedContent.length > 200) {
              // Ensure substantial content
              return cleanedContent;
            }
          }
        }
      } catch (e) {
        continue;
      }
    }

    // Enhanced fallback: try to extract content more intelligently
    try {
      final contentBuffer = StringBuffer();

      // Look for content in specific Medium patterns
      final contentElements = document.querySelectorAll(
        'article p, article h1, article h2, article h3, article h4, article h5, article h6, '
        'article blockquote, article pre, article ul, article ol, article figure, '
        '.graf--p, .graf--h3, .graf--h4, .graf--blockquote, .graf--pre, '
        '.graf--ul, .graf--ol, .graf--figure',
      );

      if (contentElements.isNotEmpty) {
        for (final element in contentElements) {
          final text = element.text.trim();

          // Skip elements that are likely not main content
          if (text.isEmpty ||
              text.length < 10 ||
              _isNavigationText(text) ||
              _isAdText(text) ||
              _isMetaText(text)) {
            continue;
          }

          // Get the tag name and inner HTML
          final tagName = element.localName ?? 'p';
          String innerHTML = element.innerHtml;

          // Clean up the innerHTML
          innerHTML = _cleanInnerHtml(innerHTML);

          if (innerHTML.isNotEmpty) {
            contentBuffer.writeln('<$tagName>$innerHTML</$tagName>');
          }
        }
      } else {
        // Last resort: get all paragraphs and headings
        final allElements = document.querySelectorAll(
          'p, h1, h2, h3, h4, h5, h6, blockquote, pre, ul, ol',
        );

        for (final element in allElements) {
          final text = element.text.trim();

          if (text.isNotEmpty &&
              text.length > 15 &&
              !_isNavigationText(text) &&
              !_isAdText(text) &&
              !_isMetaText(text)) {
            final tagName = element.localName ?? 'p';
            String innerHTML = element.innerHtml;
            innerHTML = _cleanInnerHtml(innerHTML);

            if (innerHTML.isNotEmpty) {
              contentBuffer.writeln('<$tagName>$innerHTML</$tagName>');
            }
          }
        }
      }

      final content = contentBuffer.toString().trim();
      return content.isNotEmpty ? content : 'Content could not be extracted.';
    } catch (e) {
      return 'Content could not be extracted.';
    }
  }

  bool _isMetaText(String text) {
    final metaPatterns = [
      'clap',
      'response',
      'share',
      'bookmark',
      'highlight',
      'follow',
      'member preview',
      'upgrade',
      'get unlimited',
      'become a member',
      'reading time',
      'min read',
      'published in',
      'written by',
      'tags:',
      'topics:',
      'categories:',
      'filed under',
    ];

    final lowerText = text.toLowerCase();
    return metaPatterns.any((pattern) => lowerText.contains(pattern));
  }

  String _cleanInnerHtml(String html) {
    // Remove unwanted attributes but preserve structure
    String cleaned = html;

    // Remove data attributes, classes, and IDs that might interfere
    cleaned = cleaned.replaceAll(RegExp(r'\s*data-[^=]*="[^"]*"'), '');
    cleaned = cleaned.replaceAll(RegExp(r'\s*class="[^"]*"'), '');
    cleaned = cleaned.replaceAll(RegExp(r'\s*id="[^"]*"'), '');
    cleaned = cleaned.replaceAll(RegExp(r'\s*style="[^"]*"'), '');

    // Clean up extra whitespace
    cleaned = cleaned.replaceAll(RegExp(r'\s+'), ' ');
    cleaned = cleaned.replaceAll(RegExp(r'>\s+<'), '><');

    return cleaned.trim();
  }

  void _removeUnwantedElements(html.Element contentElement) {
    // Remove Medium-specific unwanted elements
    final unwantedSelectors = [
      // Medium UI elements
      '.follow-button', '.subscribe-button', '.social-share',
      '.clap-button', '.highlight-menu', '.response-count',
      '.bookmark-button', '.member-preview-upgrade', '.paywall',

      // Navigation and meta elements
      '.related-articles', '.newsletter-signup', '.author-follow',
      '[data-testid="storyReadTime"]', '[data-testid="authorName"]',
      '[data-testid="storyPublishDate"]', '[data-testid="authorPhoto"]',

      // Ads and promotional content
      '.advertisement', '.ad-container', '.promoted-content',
      '.sponsor-content', '.affiliate-disclosure',

      // Medium-specific classes
      '.pw-multi-vote-icon', '.pw-multi-vote-count',
      '.speechify-ignore', '.grecaptcha-badge',

      // Social and interaction elements
      'button[aria-label*="clap"]', 'button[aria-label*="Share"]',
      'button[aria-label*="bookmark"]', 'button[aria-label*="Listen"]',
      'button[aria-label*="responses"]',

      // Navigation menus and headers
      'nav', 'header', 'footer', '.navigation', '.menu',
      '.sidebar', '.header', '.footer-content',

      // Scripts and style elements
      'script', 'style', 'noscript',

      // Hidden elements
      '[style*="display: none"]', '[style*="visibility: hidden"]',
      '.hidden', '.invisible',
    ];

    for (final selector in unwantedSelectors) {
      try {
        final elements = contentElement.querySelectorAll(selector);
        for (final element in elements) {
          element.remove();
        }
      } catch (e) {
        continue;
      }
    }

    // Remove elements with specific text content that indicates UI elements
    final textBasedRemovals = [
      'Follow',
      'Subscribe',
      'Sign up',
      'Sign in',
      'Member-only',
      'Upgrade',
      'Get unlimited',
      'Become a member',
      'Join Medium',
      'Open in app',
      'Download the app',
      'Continue reading',
      'Read more stories',
      'More from',
      'Recommended for you',
    ];

    try {
      final allElements = contentElement.querySelectorAll('*');
      for (final element in allElements) {
        final text = element.text.trim();
        if (text.isNotEmpty && text.length < 50) {
          for (final removal in textBasedRemovals) {
            if (text.toLowerCase().contains(removal.toLowerCase())) {
              element.remove();
              break;
            }
          }
        }
      }
    } catch (e) {
      // Continue if there's an error
    }
  }

  String _cleanHtmlContent(String htmlContent) {
    // Clean up the HTML content
    String cleaned = htmlContent;

    // Remove empty paragraphs and divs
    cleaned = cleaned.replaceAll(RegExp(r'<p[^>]*>\s*</p>'), '');
    cleaned = cleaned.replaceAll(RegExp(r'<div[^>]*>\s*</div>'), '');

    // Remove style attributes for consistent styling
    cleaned = cleaned.replaceAll(RegExp(r'\s*style="[^"]*"'), '');

    // Remove class attributes that might interfere with styling
    cleaned = cleaned.replaceAll(RegExp(r'\s*class="[^"]*"'), '');

    // Remove data attributes
    cleaned = cleaned.replaceAll(RegExp(r'\s*data-[^=]*="[^"]*"'), '');

    // Clean up extra whitespace
    cleaned = cleaned.replaceAll(RegExp(r'\s+'), ' ');
    cleaned = cleaned.replaceAll(RegExp(r'>\s+<'), '><');

    return cleaned.trim();
  }

  bool _isNavigationText(String text) {
    final navPatterns = [
      // Medium-specific UI text
      'sign up', 'sign in', 'follow', 'subscribe', 'member-only',
      'upgrade', 'get unlimited', 'become a member', 'join medium',
      'open in app', 'download the app',

      // Navigation elements
      'read more', 'continue reading', 'view all', 'see all',
      'more from', 'recommended', 'related', 'next story',
      'previous story', 'back to', 'go to',

      // Social actions
      'clap', 'share', 'bookmark', 'highlight', 'response',
      'listen', 'follow publication', 'follow author',

      // Meta information
      'min read', 'reading time', 'published in', 'written by',
      'member preview', 'this story is published in',

      // Common short phrases that are likely UI elements
      'menu', 'search', 'home', 'about', 'contact', 'help',
      'settings', 'profile', 'notifications',
    ];

    final lowerText = text.toLowerCase().trim();

    // Check for exact matches or contains for longer patterns
    return navPatterns.any((pattern) {
      if (pattern.length <= 10) {
        // For short patterns, check if the text is exactly or mostly this pattern
        return lowerText == pattern ||
            (lowerText.contains(pattern) &&
                lowerText.length <= pattern.length + 5);
      } else {
        // For longer patterns, just check if it contains the pattern
        return lowerText.contains(pattern);
      }
    });
  }

  bool _isAdText(String text) {
    final adPatterns = [
      // Advertisement indicators
      'advertisement', 'sponsored', 'promoted', 'affiliate',
      'disclosure', 'partner content', 'paid content',

      // Legal and policy text
      'privacy policy', 'terms of service', 'cookie policy',
      'terms and conditions', 'legal notice',

      // Promotional text
      'special offer', 'limited time', 'discount', 'sale',
      'buy now', 'shop now', 'learn more', 'click here',

      // Newsletter and subscription
      'newsletter', 'email list', 'mailing list', 'updates',
      'notifications', 'alerts',
    ];

    final lowerText = text.toLowerCase();
    return adPatterns.any((pattern) => lowerText.contains(pattern));
  }

  DateTime? _extractPublishDate(html.Document document) {
    // First try structured data from JSON-LD
    try {
      final scripts = document.querySelectorAll(
        'script[type="application/ld+json"]',
      );
      for (final script in scripts) {
        final jsonText = script.text;
        final patterns = [
          r'"datePublished"\s*:\s*"([^"]+)"',
          r'"dateCreated"\s*:\s*"([^"]+)"',
          r'"publishedTime"\s*:\s*"([^"]+)"',
        ];

        for (final pattern in patterns) {
          final match = RegExp(pattern).firstMatch(jsonText);
          if (match != null) {
            final dateStr = match.group(1)!;
            final date = DateTime.tryParse(dateStr);
            if (date != null) {
              return date;
            }
          }
        }
      }
    } catch (e) {
      // Continue with other methods
    }

    // Try meta tags
    final metaSelectors = [
      'meta[property="article:published_time"]',
      'meta[property="article:published"]',
      'meta[name="publish_date"]',
      'meta[name="date"]',
    ];

    for (final selector in metaSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null) {
          final content = element.attributes['content'];
          if (content != null && content.isNotEmpty) {
            final date = DateTime.tryParse(content);
            if (date != null) {
              return date;
            }
          }
        }
      } catch (e) {
        continue;
      }
    }

    // Try HTML selectors
    final dateSelectors = [
      '[data-testid="storyPublishDate"]',
      'time[datetime]',
      'time',
      '.published-date',
      '.publish-date',
      '.dt-published',
      '.post-date',
    ];

    for (final selector in dateSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null) {
          final dateText =
              element.attributes['datetime'] ??
              element.attributes['title'] ??
              element.text.trim();

          if (dateText.isNotEmpty) {
            // Try parsing different date formats
            DateTime? date = DateTime.tryParse(dateText);

            if (date == null) {
              // Try parsing common Medium date formats like "Sep 9, 2025"
              final monthNames = {
                'jan': '01',
                'feb': '02',
                'mar': '03',
                'apr': '04',
                'may': '05',
                'jun': '06',
                'jul': '07',
                'aug': '08',
                'sep': '09',
                'oct': '10',
                'nov': '11',
                'dec': '12',
              };

              final datePattern = RegExp(r'(\w{3})\s+(\d{1,2}),?\s+(\d{4})');
              final match = datePattern.firstMatch(dateText.toLowerCase());

              if (match != null) {
                final month = monthNames[match.group(1)];
                final day = match.group(2)!.padLeft(2, '0');
                final year = match.group(3);

                if (month != null) {
                  date = DateTime.tryParse('$year-$month-$day');
                }
              }
            }

            if (date != null) {
              return date;
            }
          }
        }
      } catch (e) {
        continue;
      }
    }

    return null;
  }

  String? _extractImageUrl(html.Document document) {
    // First try meta tags for featured image
    final metaSelectors = [
      'meta[property="og:image"]',
      'meta[property="twitter:image"]',
      'meta[property="twitter:image:src"]',
      'meta[name="image"]',
    ];

    for (final selector in metaSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null) {
          String? imageUrl = element.attributes['content'];
          if (imageUrl != null && imageUrl.isNotEmpty) {
            if (imageUrl.startsWith('//')) {
              imageUrl = 'https:$imageUrl';
            }
            if (imageUrl.startsWith('http') && _isValidImageUrl(imageUrl)) {
              return imageUrl;
            }
          }
        }
      } catch (e) {
        continue;
      }
    }

    // Try structured data
    try {
      final scripts = document.querySelectorAll(
        'script[type="application/ld+json"]',
      );
      for (final script in scripts) {
        final jsonText = script.text;
        final imageMatch = RegExp(
          r'"image"\s*:\s*\[?\s*"([^"]+)"',
        ).firstMatch(jsonText);
        if (imageMatch != null) {
          String imageUrl = imageMatch.group(1)!;
          if (imageUrl.startsWith('//')) {
            imageUrl = 'https:$imageUrl';
          }
          if (imageUrl.startsWith('http') && _isValidImageUrl(imageUrl)) {
            return imageUrl;
          }
        }
      }
    } catch (e) {
      // Continue with other methods
    }

    // Try HTML selectors for article images
    final imageSelectors = [
      'figure img',
      '[data-testid="storyImage"] img',
      '.graf--figure img',
      'article img:first-of-type',
      'img[data-testid="image"]',
      '.post-image img',
      '.featured-image img',
    ];

    for (final selector in imageSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null) {
          String? imageUrl =
              element.attributes['src'] ??
              element.attributes['data-src'] ??
              element.attributes['data-lazy-src'];

          if (imageUrl != null && imageUrl.isNotEmpty) {
            if (imageUrl.startsWith('//')) {
              imageUrl = 'https:$imageUrl';
            }
            if (imageUrl.startsWith('http') && _isValidImageUrl(imageUrl)) {
              // Skip small images (likely icons or avatars)
              final width = element.attributes['width'];
              final height = element.attributes['height'];

              if (width != null && height != null) {
                final w = int.tryParse(width) ?? 0;
                final h = int.tryParse(height) ?? 0;
                if (w < 200 || h < 200) {
                  continue;
                }
              }

              return imageUrl;
            }
          }
        }
      } catch (e) {
        continue;
      }
    }

    return null;
  }

  bool _isValidImageUrl(String url) {
    final imageExtensions = ['.jpg', '.jpeg', '.png', '.webp', '.gif'];
    final lowerUrl = url.toLowerCase();

    // Check if it's a Medium image URL or has valid extension
    return lowerUrl.contains('miro.medium.com') ||
        lowerUrl.contains('cdn-images') ||
        imageExtensions.any((ext) => lowerUrl.contains(ext)) ||
        lowerUrl.contains('/resize:') ||
        lowerUrl.contains('format:webp');
  }

  String? _extractAuthorImageUrl(html.Document document) {
    final authorImageSelectors = [
      '[data-testid="authorPhoto"] img',
      'img[data-testid="authorPhoto"]',
      '.avatar img',
      '.author-image img',
      '.author-avatar img',
      '.u-photo img',
      '.profile-image img',
      '.author-photo img',
      '.byline-avatar img',
      'img.avatar',
      'img[alt*="author"]',
      'img[alt*="Author"]',
    ];

    for (final selector in authorImageSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null) {
          String? imageUrl =
              element.attributes['src'] ??
              element.attributes['data-src'] ??
              element.attributes['data-lazy-src'] ??
              element.attributes['srcset']?.split(' ').first;

          if (imageUrl != null && imageUrl.isNotEmpty) {
            // Clean up the URL
            if (imageUrl.startsWith('//')) {
              imageUrl = 'https:$imageUrl';
            } else if (!imageUrl.startsWith('http')) {
              continue; // Skip relative URLs
            }

            // Validate that it's likely an image URL
            if (imageUrl.contains('avatar') ||
                imageUrl.contains('profile') ||
                imageUrl.contains('author') ||
                imageUrl.endsWith('.jpg') ||
                imageUrl.endsWith('.jpeg') ||
                imageUrl.endsWith('.png') ||
                imageUrl.endsWith('.webp')) {
              return imageUrl;
            }
          }
        }
      } catch (e) {
        continue;
      }
    }

    // Try to find author image from structured data
    try {
      final scripts = document.querySelectorAll(
        'script[type="application/ld+json"]',
      );
      for (final script in scripts) {
        final jsonText = script.text;
        if (jsonText.contains('"author"') && jsonText.contains('"image"')) {
          final imageMatch = RegExp(
            r'"author"[^}]*"image"\s*:\s*"([^"]+)"',
          ).firstMatch(jsonText);
          if (imageMatch != null) {
            return imageMatch.group(1)!;
          }
        }
      }
    } catch (e) {
      // Ignore JSON parsing errors
    }

    return null;
  }

  int? _extractReadingTime(html.Document document) {
    // Try meta tags first
    final metaSelectors = [
      'meta[name="twitter:data1"]',
      'meta[property="article:reading_time"]',
    ];

    for (final selector in metaSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null) {
          final content = element.attributes['content'];
          if (content != null && content.contains('min')) {
            final match = RegExp(r'(\d+)').firstMatch(content);
            if (match != null) {
              return int.tryParse(match.group(1)!);
            }
          }
        }
      } catch (e) {
        continue;
      }
    }

    // Try HTML selectors
    final readingTimeSelectors = [
      '[data-testid="storyReadTime"]',
      '.readingTime',
      '.reading-time',
      '.post-reading-time',
      '.read-time',
    ];

    for (final selector in readingTimeSelectors) {
      try {
        final element = document.querySelector(selector);
        if (element != null) {
          final text = element.text.toLowerCase();
          final patterns = [
            RegExp(r'(\d+)\s*min'),
            RegExp(r'(\d+)\s*minute'),
            RegExp(r'(\d+)'),
          ];

          for (final pattern in patterns) {
            final match = pattern.firstMatch(text);
            if (match != null) {
              final time = int.tryParse(match.group(1)!);
              if (time != null && time > 0 && time < 120) {
                // Reasonable range
                return time;
              }
            }
          }
        }
      } catch (e) {
        continue;
      }
    }

    // Estimate from word count
    final wordCount = _estimateWordCount(document);
    if (wordCount > 0) {
      // Average reading speed: 200-250 words per minute
      final estimatedTime = (wordCount / 225).ceil();
      return estimatedTime > 0 ? estimatedTime : 1;
    }

    return null;
  }

  int _estimateWordCount(html.Document document) {
    try {
      final contentElement = document.querySelector('article') ?? document;
      final text = contentElement.text;
      if (text == null || text.isEmpty) return 0;
      return text.split(RegExp(r'\s+')).where((word) => word.isNotEmpty).length;
    } catch (e) {
      return 0;
    }
  }

  List<String> _extractTags(html.Document document) {
    final tags = <String>[];

    // Try structured data first
    try {
      final scripts = document.querySelectorAll(
        'script[type="application/ld+json"]',
      );
      for (final script in scripts) {
        final jsonText = script.text;
        // Look for keywords or tags in JSON-LD
        final keywordMatch = RegExp(
          r'"keywords"\s*:\s*"([^"]+)"',
        ).firstMatch(jsonText);
        if (keywordMatch != null) {
          final keywords = keywordMatch.group(1)!.split(',');
          for (final keyword in keywords) {
            final cleanKeyword = keyword.trim();
            if (cleanKeyword.isNotEmpty && !tags.contains(cleanKeyword)) {
              tags.add(cleanKeyword);
            }
          }
        }
      }
    } catch (e) {
      // Continue with other methods
    }

    // Try meta tags
    final metaSelectors = [
      'meta[name="keywords"]',
      'meta[property="article:tag"]',
      'meta[name="tags"]',
    ];

    for (final selector in metaSelectors) {
      try {
        final elements = document.querySelectorAll(selector);
        for (final element in elements) {
          final content = element.attributes['content'];
          if (content != null && content.trim().isNotEmpty) {
            final tagList = content.split(',');
            for (final tag in tagList) {
              final cleanTag = tag.trim();
              if (cleanTag.isNotEmpty && !tags.contains(cleanTag)) {
                tags.add(cleanTag);
              }
            }
          }
        }
      } catch (e) {
        continue;
      }
    }

    // Try HTML selectors
    final tagSelectors = [
      '.tags a',
      '.post-tags a',
      '[data-testid="tag"]',
      '.tag',
      '.topic-tag',
      '.article-tag',
      'a[href*="/tag/"]',
      'a[href*="/topic/"]',
    ];

    for (final selector in tagSelectors) {
      try {
        final elements = document.querySelectorAll(selector);
        for (final element in elements) {
          final tagText = element.text.trim();
          if (tagText.isNotEmpty &&
              tagText.length > 1 &&
              tagText.length < 50 &&
              !tags.contains(tagText) &&
              !_isNavigationText(tagText)) {
            tags.add(tagText);
          }
        }
      } catch (e) {
        continue;
      }
    }

    // If no tags found, try to extract from URL or title
    if (tags.isEmpty) {
      try {
        // Look for common programming/tech keywords in the title
        final title = _extractTitle(document).toLowerCase();
        final techKeywords = [
          'flutter',
          'dart',
          'javascript',
          'python',
          'react',
          'nodejs',
          'programming',
          'development',
          'coding',
          'software',
          'web',
          'mobile',
          'app',
          'api',
          'database',
          'frontend',
          'backend',
          'ui',
          'ux',
          'design',
          'technology',
          'tech',
          'developer',
        ];

        for (final keyword in techKeywords) {
          if (title.contains(keyword) && !tags.contains(keyword)) {
            tags.add(
              keyword.substring(0, 1).toUpperCase() + keyword.substring(1),
            );
          }
        }
      } catch (e) {
        // Ignore errors
      }
    }

    return tags.take(8).toList(); // Increased limit for more tags
  }

  void retryLastFetch() {
    if (_urlInput.value.isNotEmpty) {
      fetchArticle(_urlInput.value);
    }
  }

  void reset() {
    _article.value = null;
    _error.value = null;
    _urlInput.value = '';
  }

  void bookmarkArticle() {
    if (_article.value != null) {
      try {
        final historyController = Get.find<ReadingHistoryController>();
        historyController.toggleFavorite(_article.value!);
      } catch (_) {}
    }
  }

  bool isBookmarked() {
    if (_article.value != null) {
      try {
        final historyController = Get.find<ReadingHistoryController>();
        return historyController.isFavorite(_article.value!);
      } catch (_) {
        return false;
      }
    }
    return false;
  }

  void setArticle(Article article) {
    _article.value = article;
    _error.value = null;
    try {
      final historyController = Get.find<ReadingHistoryController>();
      historyController.addToHistory(article);
    } catch (_) {}
  }

  // Helper method to navigate to article with URL
  static void openArticleFromUrl(String url) {
    final encodedUrl = Uri.encodeComponent(url);
    Get.toNamed('${AppRoutes.article}/$encodedUrl');
  }

  // Helper method to share article with native sharing
  Future<void> shareArticleNative() async {
    if (_article.value != null) {
      await ShareHelper.shareArticle(_article.value!);
    }
  }
}
