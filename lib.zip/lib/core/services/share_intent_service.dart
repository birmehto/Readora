import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../../features/home/controllers/home_controller.dart';
import '../utils/url_validator.dart';

class ShareIntentService extends GetxService {
  static const _channel = MethodChannel('app.channel.shared.data');
  String? pendingUrl;

  Future<ShareIntentService> init() async {
    if (!Platform.isAndroid && !Platform.isIOS) {
      return this;
    }

    // Handle incoming intents when app is running
    _channel.setMethodCallHandler((call) async {
      if (call.method == 'handleSharedUrl') {
        final String? sharedText = call.arguments as String?;
        _processSharedText(sharedText);
      }
    });

    // Check for initial intent when app starts
    try {
      final String? sharedText = await _channel.invokeMethod('getInitialUrl');
      _processSharedText(sharedText);
    } catch (e) {
      // Ignored
    }

    return this;
  }

  void _processSharedText(String? sharedText) {
    if (sharedText == null || sharedText.isEmpty) return;

    // Extract and clean URL
    String? url = UrlValidator.extractUrlFromText(sharedText);
    if (url != null) {
      url = UrlValidator.cleanTextiseUrl(url);
      if (url != null && url.isNotEmpty) {
        _openArticle(url);
      }
    }
  }

  void _openArticle(String url) {
    if (Get.isRegistered<HomeController>()) {
      final homeController = Get.find<HomeController>();
      homeController.urlController.text = url;
      homeController.onUrlChanged(url);
      WidgetsBinding.instance.addPostFrameCallback((_) => homeController.openArticle());
    } else {
      pendingUrl = url;
    }
  }
}
