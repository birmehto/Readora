import 'package:flutter/material.dart';
import 'package:free/core/core.dart';
import 'package:get/get.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import '../../article/model.dart';
import '../../article/controller/article_controller.dart';
import '../controller/reading_history_controller.dart';

class HistoryView extends GetView<ReadingHistoryController> {
  const HistoryView({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: Theme.of(context).colorScheme.surface,
        body: CustomScrollView(
          slivers: [
            SliverAppBar.medium(
              title: Text(
                'History',
                style: AppTypography.headlineMedium(context),
              ),
              bottom: TabBar(
                tabs: const [
                  Tab(text: 'Recent', icon: Icon(Icons.history)),
                  Tab(text: 'Favorites', icon: Icon(Icons.favorite)),
                ],
                labelStyle: AppTypography.titleSmall(context),
              ),
              actions: [
                PopupMenuButton<String>(
                  onSelected: (value) {
                    if (value == 'clear_history') {
                      _showClearHistoryDialog(context);
                    }
                  },
                  itemBuilder: (context) => [
                    const PopupMenuItem(
                      value: 'clear_history',
                      child: Row(
                        children: [
                          Icon(Icons.clear_all),
                          SizedBox(width: 8),
                          Text('Clear History'),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SliverFillRemaining(
              child: TabBarView(
                children: [
                  _buildHistoryTab(context),
                  _buildFavoritesTab(context),
                ],
              ),
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => Get.offAllNamed('/'),
          icon: const Icon(Icons.add),
          label: const Text('Read Article'),
        ),
      ),
    );
  }

  Widget _buildHistoryTab(BuildContext context) {
    return Obx(() {
      if (controller.history.isEmpty) {
        return _buildEmptyState(
          context,
          'No articles read yet',
          'Articles you read will appear here',
          Icons.history_outlined,
        );
      }

      return CustomScrollView(
        slivers: [
          SliverToBoxAdapter(child: _buildStatsSection(context)),
          SliverList(
            delegate: SliverChildBuilderDelegate((context, index) {
              final article = controller.history[index];
              return Padding(
                padding: EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                child: _buildArticleCard(context, article, index)
                    .animate(delay: (index * 100).ms)
                    .fadeIn(duration: 500.ms)
                    .slideX(begin: 0.3, end: 0),
              );
            }, childCount: controller.history.length),
          ),
        ],
      );
    });
  }

  Widget _buildFavoritesTab(BuildContext context) {
    return Obx(() {
      if (controller.favorites.isEmpty) {
        return _buildEmptyState(
          context,
          'No favorites yet',
          'Tap the heart icon on articles to save them here',
          Icons.favorite_outline,
        );
      }

      return ListView.builder(
        padding: EdgeInsets.all(AppSpacing.lg),
        itemCount: controller.favorites.length,
        itemBuilder: (context, index) {
          final article = controller.favorites[index];
          return _buildArticleCard(context, article, index, isFavorite: true)
              .animate(delay: (index * 100).ms)
              .fadeIn(duration: 500.ms)
              .slideX(begin: 0.3, end: 0);
        },
      );
    });
  }

  Widget _buildEmptyState(
    BuildContext context,
    String title,
    String subtitle,
    IconData icon,
  ) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(AppSpacing.xl),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 80,
              color: Theme.of(
                context,
              ).colorScheme.outline.withValues(alpha: 0.5),
            ),
            SizedBox(height: AppSpacing.lg),
            Text(
              title,
              style: AppTypography.headlineSmall(
                context,
              ).copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
            SizedBox(height: AppSpacing.sm),
            Text(
              subtitle,
              style: AppTypography.bodyLarge(
                context,
              ).copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    ).animate().fadeIn(delay: 200.ms);
  }

  Widget _buildArticleCard(
    BuildContext context,
    Article article,
    int index, {
    bool isFavorite = false,
  }) {
    return Card(
      margin: EdgeInsets.only(bottom: AppSpacing.md),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: Theme.of(context).dividerColor.withValues(alpha: 0.5),
        ),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _openArticle(article),
        child: Padding(
          padding: EdgeInsets.all(AppSpacing.lg),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      article.title,
                      style: AppTypography.titleMedium(context),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  PopupMenuButton<String>(
                    onSelected: (value) => _handleMenuAction(value, article),
                    itemBuilder: (context) => [
                      PopupMenuItem(
                        value: 'favorite',
                        child: Row(
                          children: [
                            Icon(
                              controller.isFavorite(article)
                                  ? Icons.favorite_border
                                  : Icons.favorite,
                              color: controller.isFavorite(article)
                                  ? null
                                  : Colors.red,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              controller.isFavorite(article)
                                  ? 'Remove from Favorites'
                                  : 'Add to Favorites',
                            ),
                          ],
                        ),
                      ),
                      if (!isFavorite)
                        const PopupMenuItem(
                          value: 'remove',
                          child: Row(
                            children: [
                              Icon(Icons.delete_outline, color: Colors.red),
                              SizedBox(width: 8),
                              Text('Remove from History'),
                            ],
                          ),
                        ),
                    ],
                  ),
                ],
              ),
              SizedBox(height: AppSpacing.sm),
              Row(
                children: [
                  CircleAvatar(
                    radius: 16,
                    backgroundColor: Theme.of(
                      context,
                    ).colorScheme.primary.withValues(alpha: 0.1),
                    child: Text(
                      article.author.isNotEmpty
                          ? article.author[0].toUpperCase()
                          : 'A',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.primary,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          article.author,
                          style: AppTypography.bodyMedium(context),
                        ),
                        if (article.publishedDate != null)
                          Text(
                            _formatDate(article.publishedDate!),
                            style: AppTypography.bodySmall(context).copyWith(
                              color: Theme.of(
                                context,
                              ).colorScheme.onSurfaceVariant,
                            ),
                          ),
                      ],
                    ),
                  ),
                  if (article.readingTime != null)
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: AppSpacing.sm,
                        vertical: AppSpacing.xs,
                      ),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primaryContainer,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '${article.readingTime} min',
                        style: AppTypography.bodySmall(context).copyWith(
                          color: Theme.of(
                            context,
                          ).colorScheme.onPrimaryContainer,
                        ),
                      ),
                    ),
                ],
              ),
              if (article.subtitle != null) ...[
                SizedBox(height: AppSpacing.sm),
                Text(
                  article.subtitle!,
                  style: AppTypography.bodyMedium(context).copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
              if (article.tags.isNotEmpty) ...[
                SizedBox(height: AppSpacing.sm),
                Wrap(
                  spacing: AppSpacing.xs,
                  runSpacing: AppSpacing.xs,
                  children: article.tags.take(3).map((tag) {
                    return Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: AppSpacing.sm,
                        vertical: AppSpacing.xs,
                      ),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.surfaceContainer,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(tag, style: AppTypography.bodySmall(context)),
                    );
                  }).toList(),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  void _openArticle(Article article) {
    final articleController = Get.find<ArticleController>();
    articleController.setArticle(article);
    Get.toNamed('/article');
  }

  void _handleMenuAction(String action, Article article) {
    switch (action) {
      case 'favorite':
        controller.toggleFavorite(article);
        break;
      case 'remove':
        controller.removeFromHistory(article);
        Get.snackbar(
          'Removed',
          'Article removed from history',
          snackPosition: SnackPosition.BOTTOM,
          duration: const Duration(seconds: 2),
        );
        break;
    }
  }

  void _showClearHistoryDialog(BuildContext context) {
    Get.dialog(
      AlertDialog(
        title: const Text('Clear History'),
        content: const Text(
          'Are you sure you want to clear all reading history? This action cannot be undone.',
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              controller.clearHistory();
              Get.back();
              Get.snackbar(
                'Cleared',
                'Reading history cleared',
                snackPosition: SnackPosition.BOTTOM,
                duration: const Duration(seconds: 2),
              );
            },
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays > 7) {
      return DateFormat('MMM dd, yyyy').format(date);
    } else if (difference.inDays > 0) {
      return '${difference.inDays} days ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours} hours ago';
    } else {
      return 'Just now';
    }
  }

  Widget _buildStatsSection(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(AppSpacing.lg),
      child: Card(
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
            color: Theme.of(context).dividerColor.withValues(alpha: 0.5),
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(AppSpacing.lg),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    Icons.analytics_outlined,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  SizedBox(width: AppSpacing.sm),
                  Text(
                    'Reading Stats',
                    style: AppTypography.titleMedium(context),
                  ),
                ],
              ),
              SizedBox(height: AppSpacing.md),
              Row(
                children: [
                  Expanded(
                    child: _buildStatItem(
                      context,
                      'Articles Read',
                      controller.totalArticlesRead.toString(),
                      Icons.article_outlined,
                    ),
                  ),
                  Expanded(
                    child: _buildStatItem(
                      context,
                      'Favorites',
                      controller.totalFavorites.toString(),
                      Icons.favorite_outline,
                    ),
                  ),
                  Expanded(
                    child: _buildStatItem(
                      context,
                      'Reading Time',
                      '${controller.totalReadingTime} min',
                      Icons.schedule_outlined,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ).animate().fadeIn(duration: 600.ms).slideY(begin: 0.2, end: 0),
    );
  }

  Widget _buildStatItem(
    BuildContext context,
    String label,
    String value,
    IconData icon,
  ) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(AppSpacing.sm),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primaryContainer,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: Theme.of(context).colorScheme.onPrimaryContainer,
            size: 20,
          ),
        ),
        SizedBox(height: AppSpacing.sm),
        Text(
          value,
          style: AppTypography.titleMedium(
            context,
          ).copyWith(fontWeight: FontWeight.bold),
        ),
        Text(
          label,
          style: AppTypography.bodySmall(
            context,
          ).copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
