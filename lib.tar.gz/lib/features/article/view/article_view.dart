import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';
import '../../../core/constants/app_spacing.dart';
import '../../../core/constants/app_typography.dart';
import '../controller/article_controller.dart';

class ArticleView extends GetView<ArticleController> {
  const ArticleView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() {
        final article = controller.article;
        if (article == null) {
          return const Center(child: Text('No article to display'));
        }

        return CustomScrollView(
          slivers: [
            SliverAppBar.large(
              title: Text(
                article.title,
                style: AppTypography.headlineSmall(context),
              ),
              actions: [
                IconButton(
                  icon: Obx(
                    () => Icon(
                      controller.isBookmarked()
                          ? Icons.favorite
                          : Icons.favorite_border,
                      color: controller.isBookmarked() ? Colors.red : null,
                    ),
                  ),
                  onPressed: controller.bookmarkArticle,
                ),
                IconButton(
                  icon: const Icon(Icons.share),
                  onPressed: () => Share.share(article.originalUrl),
                ),
                IconButton(
                  icon: const Icon(Icons.open_in_browser),
                  onPressed: () => launchUrl(Uri.parse(article.originalUrl)),
                ),
              ],
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.all(AppSpacing.lg),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildArticleHeader(context, article),
                    SizedBox(height: AppSpacing.xl),
                    _buildArticleContent(context, article),
                  ],
                ),
              ),
            ),
          ],
        );
      }),
    );
  }

  Widget _buildArticleHeader(BuildContext context, article) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CircleAvatar(
              radius: 20,
              backgroundColor: Theme.of(
                context,
              ).colorScheme.primary.withValues(alpha: 0.1),
              child: Text(
                article.author.isNotEmpty
                    ? article.author[0].toUpperCase()
                    : 'A',
                style: TextStyle(
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(width: AppSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    article.author,
                    style: AppTypography.titleMedium(context),
                  ),
                  if (article.publishedDate != null)
                    Text(
                      _formatDate(article.publishedDate!),
                      style: AppTypography.bodySmall(context),
                    ),
                ],
              ),
            ),
          ],
        ),
        if (article.readingTime != null) ...[
          SizedBox(height: AppSpacing.sm),
          Container(
            padding: EdgeInsets.symmetric(
              horizontal: AppSpacing.sm,
              vertical: AppSpacing.xs,
            ),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              '${article.readingTime} min read',
              style: AppTypography.bodySmall(context).copyWith(
                color: Theme.of(context).colorScheme.onPrimaryContainer,
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildArticleContent(BuildContext context, article) {
    return Html(
      data: article.content,
      style: {
        "body": Style(
          fontSize: FontSize(16),
          lineHeight: const LineHeight(1.6),
          color: Theme.of(context).colorScheme.onSurface,
        ),
        "h1, h2, h3, h4, h5, h6": Style(
          color: Theme.of(context).colorScheme.onSurface,
          fontWeight: FontWeight.bold,
        ),
        "p": Style(margin: Margins.only(bottom: 16)),
        "blockquote": Style(
          border: Border(
            left: BorderSide(
              color: Theme.of(context).colorScheme.primary,
              width: 4,
            ),
          ),
          padding: HtmlPaddings.only(left: 16),
          margin: Margins.symmetric(vertical: 16),
          backgroundColor: Theme.of(context).colorScheme.surfaceContainer,
        ),
      },
      onLinkTap: (url, _, _) {
        if (url != null) {
          launchUrl(Uri.parse(url));
        }
      },
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays > 7) {
      return '${date.day}/${date.month}/${date.year}';
    } else if (difference.inDays > 0) {
      return '${difference.inDays} days ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours} hours ago';
    } else {
      return 'Just now';
    }
  }
}
