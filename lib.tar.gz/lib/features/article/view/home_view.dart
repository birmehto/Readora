import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:free/core/core.dart';
import 'package:get/get.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../widgets/enhanced_error_widget.dart';
import '../../../widgets/lottie_loading.dart';
import '../controller/article_controller.dart';

class HomeView extends GetView<ArticleController> {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    final urlController = TextEditingController();

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: CustomScrollView(
        slivers: [
          SliverAppBar.medium(
            title: Text(
              'Article Reader',
              style: AppTypography.headlineMedium(context),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.history_outlined),
                onPressed: () => Get.toNamed((AppRoutes.history)),
                tooltip: 'History',
              ),
              IconButton(
                icon: const Icon(Icons.settings_outlined),
                onPressed: () => Get.toNamed(AppRoutes.settings),
                tooltip: 'Settings',
              ),
              const SizedBox(width: 8),
            ],
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.all(AppSpacing.screenPadding),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildUrlInputSection(context, urlController),
                  SizedBox(height: AppSpacing.xl),
                  _buildContentSection(context),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUrlInputSection(
    BuildContext context,
    TextEditingController urlController,
  ) {
    return Card(
      elevation: 0,
      color: Theme.of(context).colorScheme.surfaceContainer,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Read Article',
              style: Theme.of(
                context,
              ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: urlController,
              decoration: InputDecoration(
                hintText: 'Paste Medium URL here',
                prefixIcon: const Icon(Icons.link),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.paste),
                  onPressed: () async {
                    final data = await Clipboard.getData(Clipboard.kTextPlain);
                    if (data?.text != null) {
                      urlController.text = data!.text!;
                      controller.setUrlInput(data.text!);
                    }
                  },
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Theme.of(context).colorScheme.surface,
              ),
              onChanged: controller.setUrlInput,
              onSubmitted: (val) => controller.fetchArticle(val),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () => controller.fetchArticle(urlController.text),
              icon: const Icon(Icons.auto_stories),
              label: const Text('Read Now'),
              style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
      ),
    ).animate().fadeIn(duration: 500.ms).slideY(begin: 0.1, end: 0);
  }

  Widget _buildContentSection(BuildContext context) {
    return Obx(() {
      if (controller.isLoading) {
        return const Center(
          child: ArticleLoadingAnimation(message: 'Fetching your article...'),
        );
      } else if (controller.error != null) {
        return EnhancedErrorWidget(
          error: controller.error!,
          onRetry: controller.retryLastFetch,
        );
      } else {
        return _buildEmptyState(context);
      }
    });
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.article_outlined,
            size: 64,
            color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'Paste a URL to start reading',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    ).animate().fadeIn(delay: 200.ms);
  }
}
