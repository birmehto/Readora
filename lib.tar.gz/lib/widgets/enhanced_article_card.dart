import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import '../core/constants/app_spacing.dart';
import '../core/constants/app_typography.dart';
import '../features/article/model.dart';

class EnhancedArticleCard extends StatelessWidget {
  final Article article;
  final VoidCallback? onTap;

  const EnhancedArticleCard({super.key, required this.article, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.r),
        side: BorderSide(color: Theme.of(context).dividerColor, width: 1),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Hero image
            if (article.imageUrl != null) _buildHeroImage(context),

            // Content
            Padding(
              padding: EdgeInsets.all(AppSpacing.lg),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Success indicator
                  _buildSuccessIndicator(context),

                  SizedBox(height: AppSpacing.md),

                  // Title
                  Text(
                    article.title,
                    style: AppTypography.titleLarge(context),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),

                  // Subtitle
                  if (article.subtitle != null) ...[
                    SizedBox(height: AppSpacing.sm),
                    Text(
                      article.subtitle!,
                      style: AppTypography.bodyMedium(context).copyWith(
                        color: Theme.of(
                          context,
                        ).colorScheme.onSurface.withValues(alpha: 0.7),
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],

                  SizedBox(height: AppSpacing.md),

                  // Author and metadata
                  _buildAuthorSection(context),

                  SizedBox(height: AppSpacing.md),

                  // Tags
                  if (article.tags.isNotEmpty) _buildTagsSection(context),

                  SizedBox(height: AppSpacing.lg),

                  // Action button
                  _buildActionButton(context),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeroImage(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.vertical(top: Radius.circular(16.r)),
      child: SizedBox(
        width: double.infinity,
        height: 200.h,
        child: CachedNetworkImage(
          imageUrl: article.imageUrl!,
          fit: BoxFit.cover,
          placeholder: (context, url) => Container(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            child: const Center(child: CircularProgressIndicator()),
          ),
          errorWidget: (context, url, error) => Container(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            child: Icon(
              Icons.image_not_supported_outlined,
              size: 48.sp,
              color: Theme.of(
                context,
              ).colorScheme.onSurface.withValues(alpha: 0.6),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSuccessIndicator(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: AppSpacing.sm,
        vertical: AppSpacing.xs,
      ),
      decoration: BoxDecoration(
        color: Colors.green.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20.r),
        border: Border.all(color: Colors.green.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.check_circle_outline, size: 16.sp, color: Colors.green),
          SizedBox(width: AppSpacing.xs),
          Text(
            'Article loaded successfully',
            style: AppTypography.labelSmall(
              context,
            ).copyWith(color: Colors.green, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }

  Widget _buildAuthorSection(BuildContext context) {
    return Row(
      children: [
        // Author avatar
        CircleAvatar(
          radius: 16.r,
          backgroundImage: article.authorImageUrl != null
              ? CachedNetworkImageProvider(article.authorImageUrl!)
              : null,
          backgroundColor: Theme.of(context).colorScheme.primary,
          child: article.authorImageUrl == null
              ? Text(
                  article.author.isNotEmpty
                      ? article.author[0].toUpperCase()
                      : 'A',
                  style: AppTypography.labelMedium(
                    context,
                  ).copyWith(color: Colors.white),
                )
              : null,
        ),

        SizedBox(width: AppSpacing.sm),

        // Author info
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                article.author,
                style: AppTypography.labelLarge(context),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              if (article.publishedDate != null || article.readingTime != null)
                Text(
                  _buildMetadataText(),
                  style: AppTypography.labelSmall(context).copyWith(
                    color: Theme.of(
                      context,
                    ).colorScheme.onSurface.withValues(alpha: 0.6),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTagsSection(BuildContext context) {
    return Wrap(
      spacing: AppSpacing.xs,
      runSpacing: AppSpacing.xs,
      children: article.tags.take(3).map<Widget>((tag) {
        return Container(
          padding: EdgeInsets.symmetric(
            horizontal: AppSpacing.sm,
            vertical: AppSpacing.xs,
          ),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(12.r),
          ),
          child: Text(
            tag,
            style: AppTypography.labelSmall(
              context,
            ).copyWith(color: Theme.of(context).colorScheme.primary),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildActionButton(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 48.h,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: const Icon(Icons.auto_stories),
        label: const Text('Read Full Article'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Theme.of(context).colorScheme.primary,
          foregroundColor: Theme.of(context).colorScheme.onPrimary,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.r),
          ),
        ),
      ),
    );
  }

  String _buildMetadataText() {
    final parts = <String>[];

    if (article.publishedDate != null) {
      parts.add(_formatDate(article.publishedDate!));
    }

    if (article.readingTime != null) {
      parts.add('${article.readingTime} min read');
    }

    return parts.join(' • ');
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays == 0) {
      return 'Today';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return DateFormat('MMM d, y').format(date);
    }
  }
}
