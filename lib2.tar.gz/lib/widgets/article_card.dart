import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../core/core.dart';
import '../features/article/model.dart';
import 'author_avatar.dart';
import 'tag_chip.dart';

class ArticleCard extends StatelessWidget {
  final Article article;
  final VoidCallback? onTap;

  const ArticleCard({super.key, required this.article, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.r),
        side: BorderSide(color: Theme.of(context).dividerColor, width: 1),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Hero image
            if (article.imageUrl != null) _buildHeroImage(context),

            // Content
            Padding(
              padding: EdgeInsets.all(AppSpacing.lg),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Success indicator
                  _buildSuccessIndicator(context),

                  SizedBox(height: AppSpacing.md),

                  // Title
                  Text(
                    article.title,
                    style: AppTypography.titleLarge(context),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),

                  // Subtitle
                  if (article.subtitle != null) ...[
                    SizedBox(height: AppSpacing.sm),
                    Text(
                      article.subtitle!,
                      style: AppTypography.bodyMedium(context).copyWith(
                        color: Theme.of(
                          context,
                        ).colorScheme.onSurface.withValues(alpha: 0.7),
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],

                  SizedBox(height: AppSpacing.md),

                  // Author and metadata
                  AuthorInfo(
                    authorName: article.author,
                    authorImageUrl: article.authorImageUrl,
                    subtitle: _buildMetadataText(),
                    avatarRadius: 16,
                  ),

                  SizedBox(height: AppSpacing.md),

                  // Tags
                  if (article.tags.isNotEmpty)
                    TagsWrap(
                      tags: article.tags,
                      backgroundColor: Theme.of(
                        context,
                      ).colorScheme.primary.withValues(alpha: 0.1),
                      textColor: Theme.of(context).colorScheme.primary,
                    ),

                  SizedBox(height: AppSpacing.lg),

                  // Action button
                  _buildActionButton(context),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeroImage(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.vertical(top: Radius.circular(16.r)),
      child: SizedBox(
        width: double.infinity,
        height: 200.h,
        child: CachedNetworkImage(
          imageUrl: article.imageUrl!,
          fit: BoxFit.cover,
          placeholder: (context, url) => Container(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            child: const Center(child: CircularProgressIndicator()),
          ),
          errorWidget: (context, url, error) => Container(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            child: Icon(
              Icons.image_not_supported_outlined,
              size: 48.sp,
              color: Theme.of(
                context,
              ).colorScheme.onSurface.withValues(alpha: 0.6),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSuccessIndicator(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: AppSpacing.sm,
        vertical: AppSpacing.xs,
      ),
      decoration: BoxDecoration(
        color: Colors.green.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20.r),
        border: Border.all(color: Colors.green.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.check_circle_outline, size: 16.sp, color: Colors.green),
          SizedBox(width: AppSpacing.xs),
          Text(
            'Article loaded successfully',
            style: AppTypography.labelSmall(
              context,
            ).copyWith(color: Colors.green, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 48.h,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: const Icon(Icons.auto_stories),
        label: const Text('Read Full Article'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Theme.of(context).colorScheme.primary,
          foregroundColor: Theme.of(context).colorScheme.onPrimary,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.r),
          ),
        ),
      ),
    );
  }

  String _buildMetadataText() {
    final parts = <String>[];

    if (article.publishedDate != null) {
      parts.add(DateFormatter.formatSimpleDate(article.publishedDate!));
    }

    if (article.readingTime != null) {
      parts.add('${article.readingTime} min read');
    }

    return parts.join(' • ');
  }
}
