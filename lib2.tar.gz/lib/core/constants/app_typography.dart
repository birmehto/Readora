import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'app_colors.dart';

class AppTypography {
  // Display styles
  static TextStyle displayLarge(BuildContext context) => TextStyle(
    fontSize: 32.sp,
    fontWeight: FontWeight.w700,
    height: 1.2,
    color: AppColors.textPrimary(context),
    letterSpacing: -0.5,
  );

  static TextStyle displayMedium(BuildContext context) => TextStyle(
    fontSize: 28.sp,
    fontWeight: FontWeight.w600,
    height: 1.3,
    color: AppColors.textPrimary(context),
    letterSpacing: -0.25,
  );

  static TextStyle displaySmall(BuildContext context) => TextStyle(
    fontSize: 24.sp,
    fontWeight: FontWeight.w600,
    height: 1.3,
    color: AppColors.textPrimary(context),
  );

  // Headline styles
  static TextStyle headlineLarge(BuildContext context) => TextStyle(
    fontSize: 22.sp,
    fontWeight: FontWeight.w600,
    height: 1.4,
    color: AppColors.textPrimary(context),
  );

  static TextStyle headlineMedium(BuildContext context) => TextStyle(
    fontSize: 20.sp,
    fontWeight: FontWeight.w600,
    height: 1.4,
    color: AppColors.textPrimary(context),
  );

  static TextStyle headlineSmall(BuildContext context) => TextStyle(
    fontSize: 18.sp,
    fontWeight: FontWeight.w500,
    height: 1.4,
    color: AppColors.textPrimary(context),
  );

  // Title styles
  static TextStyle titleLarge(BuildContext context) => TextStyle(
    fontSize: 18.sp,
    fontWeight: FontWeight.w600,
    height: 1.4,
    color: AppColors.textPrimary(context),
  );

  static TextStyle titleMedium(BuildContext context) => TextStyle(
    fontSize: 16.sp,
    fontWeight: FontWeight.w500,
    height: 1.4,
    color: AppColors.textPrimary(context),
  );

  static TextStyle titleSmall(BuildContext context) => TextStyle(
    fontSize: 14.sp,
    fontWeight: FontWeight.w500,
    height: 1.4,
    color: AppColors.textPrimary(context),
  );

  // Body styles
  static TextStyle bodyLarge(BuildContext context) => TextStyle(
    fontSize: 16.sp,
    fontWeight: FontWeight.w400,
    height: 1.6,
    color: AppColors.textPrimary(context),
  );

  static TextStyle bodyMedium(BuildContext context) => TextStyle(
    fontSize: 14.sp,
    fontWeight: FontWeight.w400,
    height: 1.5,
    color: AppColors.textSecondary(context),
  );

  static TextStyle bodySmall(BuildContext context) => TextStyle(
    fontSize: 12.sp,
    fontWeight: FontWeight.w400,
    height: 1.4,
    color: AppColors.textTertiary(context),
  );

  // Label styles
  static TextStyle labelLarge(BuildContext context) => TextStyle(
    fontSize: 14.sp,
    fontWeight: FontWeight.w500,
    height: 1.4,
    color: AppColors.textPrimary(context),
    letterSpacing: 0.1,
  );

  static TextStyle labelMedium(BuildContext context) => TextStyle(
    fontSize: 12.sp,
    fontWeight: FontWeight.w500,
    height: 1.3,
    color: AppColors.textSecondary(context),
    letterSpacing: 0.5,
  );

  static TextStyle labelSmall(BuildContext context) => TextStyle(
    fontSize: 11.sp,
    fontWeight: FontWeight.w500,
    height: 1.3,
    color: AppColors.textTertiary(context),
    letterSpacing: 0.5,
  );

  // Special styles
  static TextStyle caption(BuildContext context) => TextStyle(
    fontSize: 12.sp,
    fontWeight: FontWeight.w400,
    height: 1.3,
    color: AppColors.textTertiary(context),
  );

  static TextStyle overline(BuildContext context) => TextStyle(
    fontSize: 10.sp,
    fontWeight: FontWeight.w500,
    height: 1.6,
    color: AppColors.textTertiary(context),
    letterSpacing: 1.5,
  );

  // Reading content styles
  static TextStyle articleTitle(BuildContext context) => TextStyle(
    fontSize: 24.sp,
    fontWeight: FontWeight.w700,
    height: 1.3,
    color: AppColors.textPrimary(context),
    letterSpacing: -0.25,
  );

  static TextStyle articleSubtitle(BuildContext context) => TextStyle(
    fontSize: 18.sp,
    fontWeight: FontWeight.w400,
    height: 1.4,
    color: AppColors.textSecondary(context),
  );

  static TextStyle articleBody(BuildContext context) => TextStyle(
    fontSize: 16.sp,
    fontWeight: FontWeight.w400,
    height: 1.7,
    color: AppColors.textPrimary(context),
  );

  static TextStyle articleAuthor(BuildContext context) => TextStyle(
    fontSize: 14.sp,
    fontWeight: FontWeight.w500,
    height: 1.4,
    color: AppColors.textSecondary(context),
  );

  static TextStyle articleMeta(BuildContext context) => TextStyle(
    fontSize: 12.sp,
    fontWeight: FontWeight.w400,
    height: 1.3,
    color: AppColors.textTertiary(context),
  );

  static TextStyle articleQuote(BuildContext context) => TextStyle(
    fontSize: 16.sp,
    fontWeight: FontWeight.w400,
    height: 1.6,
    fontStyle: FontStyle.italic,
    color: AppColors.textSecondary(context),
  );
}
