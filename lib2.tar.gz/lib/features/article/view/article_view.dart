// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';
import '../../../core/core.dart';
import '../../../widgets/widgets.dart';
import '../controller/article_controller.dart';

class ArticleView extends GetView<ArticleController> {
  const ArticleView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() {
        final article = controller.article;
        if (article == null) {
          return const Center(child: Text('No article to display'));
        }

        return CustomScrollView(
          slivers: [
            SliverAppBar.large(
              title: Text(
                article.title,
                style: AppTypography.headlineSmall(context),
              ),
              actions: [
                IconButton(
                  icon: Obx(
                    () => Icon(
                      controller.isBookmarked()
                          ? Icons.favorite
                          : Icons.favorite_border,
                      color: controller.isBookmarked() ? Colors.red : null,
                    ),
                  ),
                  onPressed: controller.bookmarkArticle,
                ),
                IconButton(
                  icon: const Icon(Icons.share),
                  onPressed: () => Share.share(article.originalUrl),
                ),
                IconButton(
                  icon: const Icon(Icons.open_in_browser),
                  onPressed: () => launchUrl(Uri.parse(article.originalUrl)),
                ),
              ],
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.all(AppSpacing.lg),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildArticleHeader(context, article),
                    SizedBox(height: AppSpacing.xl),
                    _buildArticleContent(context, article),
                  ],
                ),
              ),
            ),
          ],
        );
      }),
    );
  }

  Widget _buildArticleHeader(BuildContext context, article) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AuthorInfo(
          authorName: article.author,
          authorImageUrl: article.authorImageUrl,
          subtitle: article.publishedDate != null
              ? DateFormatter.formatShortDate(article.publishedDate!)
              : null,
        ),
        if (article.readingTime != null) ...[
          SizedBox(height: AppSpacing.sm),
          ReadingTimeBadge(readingTime: article.readingTime!),
        ],
      ],
    );
  }

  Widget _buildArticleContent(BuildContext context, article) {
    return Html(
      data: article.content,
      style: {
        "body": Style(
          fontSize: FontSize(16),
          lineHeight: const LineHeight(1.6),
          color: Theme.of(context).colorScheme.onSurface,
        ),
        "h1, h2, h3, h4, h5, h6": Style(
          color: Theme.of(context).colorScheme.onSurface,
          fontWeight: FontWeight.bold,
        ),
        "p": Style(margin: Margins.only(bottom: 16)),
        "blockquote": Style(
          border: Border(
            left: BorderSide(
              color: Theme.of(context).colorScheme.primary,
              width: 4,
            ),
          ),
          padding: HtmlPaddings.only(left: 16),
          margin: Margins.symmetric(vertical: 16),
          backgroundColor: Theme.of(context).colorScheme.surfaceContainer,
        ),
      },
      onLinkTap: (url, _, _) {
        if (url != null) {
          launchUrl(Uri.parse(url));
        }
      },
    );
  }
}
